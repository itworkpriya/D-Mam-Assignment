

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <div class ="card-header">Products</div>
              <div class="card-body">
                  <table class ="table-border" width="100%">
                      <thead>
                          <td>Name</td>
                          <td>Price</td>
                          <td>Status</td>
                          <td>Action</td>
                      </thead>
                     <tbody>
                  <?php if($products->isNotEmpty()): ?>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->product_name); ?></td>
                            <td><?php echo e($product->product_price); ?></td>
                            <td><?php echo e($product->product_status); ?></td>
                            <td><a href="<?php echo e(url('Product/edit')); ?>/<?php echo e($product->product_id); ?>" class="btn btn-primary">Update</a>
                             <a href="<?php echo e(url('Product/delete')); ?>/<?php echo e($product->product_id); ?>" class="btn btn-danger">Delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                      </tbody>
                  </table>
              </div>

                 <div class="card-body">

                    <form action ="<?php echo e(url('Product/store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class ="form-group">
                    <label>Product Name</label>
                    <input type="text" class="form-control"name="product_name" value="<?php echo e(old('product_name')); ?>" >
                    <small class="text-danger"><?php echo e($errors->first('product_name')); ?></small>
 

                </div>
                    
                    <div class="form-group">
                        <label>Product Price</label>
                        <input type="number" class="form-control"name="product_price">
                         <small class="text-danger"><?php echo e($errors->first('product_price')); ?></small> 

                    </div>

                    <div class="form-group">
                        <label>Product Description</label>
                        <textarea class="form-control" name="product_description"></textarea>
                    </div>



                    <div class="form-group">
                        
                        <input type="submit" name="submit" value="submit">

                    </div>


                    </form>
                
                   
                </div> 
            </div>
        </div>
    </div>
</div>
<script type="text/javascript"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assignment\resources\views/Product.blade.php ENDPATH**/ ?>