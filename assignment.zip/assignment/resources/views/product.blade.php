@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <div class ="card-header">Products</div>
              <div class="card-body">
                  <table class ="table-border" width="100%">
                      <thead>
                          <td>Name</td>
                          <td>Price</td>
                          <td>Status</td>
                          <td>Action</td>
                      </thead>
                     <tbody>
                  @if($products->isNotEmpty())
                  @foreach($products as $product)
                        <tr>
                            <td>{{$product->product_name}}</td>
                            <td>{{$product->product_price}}</td>
                            <td>{{$product->product_status}}</td>
                            <td><a href="{{url('Product/edit')}}/{{$product->product_id}}" class="btn btn-primary">Update</a>
                             <a href="{{url('Product/delete')}}/{{$product->product_id}}" class="btn btn-danger">Delete</a></td>
                        </tr>
                        @endforeach
                    @endif
                      </tbody>
                  </table>
              </div>

                 <div class="card-body">

                    <form action ="{{url('Product/store')}}" method="post">
                    @csrf
                    <div class ="form-group">
                    <label>Product Name</label>
                    <input type="text" class="form-control"name="product_name" value="{{old('product_name')}}" >
                    <small class="text-danger">{{$errors->first('product_name')}}</small>
 

                </div>
                    
                    <div class="form-group">
                        <label>Product Price</label>
                        <input type="number" class="form-control"name="product_price">
                         <small class="text-danger">{{$errors->first('product_price')}}</small> 

                    </div>

                    <div class="form-group">
                        <label>Product Description</label>
                        <textarea class="form-control" name="product_description"></textarea>
                    </div>



                    <div class="form-group">
                        
                        <input type="submit" name="submit" value="submit">

                    </div>


                    </form>
                
                   
                </div> 
            </div>
        </div>
    </div>
</div>
<script type="text/javascript"></script>
@endsection

