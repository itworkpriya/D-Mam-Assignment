<?php

namespace App\Http\Controllers;

// use Illuminate\Http\Request;
// use Validator;
// use Response;
// use App\Models\ProductCategory;

// class ProductCategory extends Controller
// {
//     public function index(){
//         $product =ProductCategory::where('product_category_status','Active')->get(); 
//     return view('ProductCategory',compact('ProductCategory'));
//     }

//     public function store(Request $request){
//         $input = $request-> all();
       

//       //  return Validator::make($input, [
//          //   'product_category_name' => ['required', 'string', 'unique:Product','max:50'],
//           //  'product_category_price' => ['required'],
           
//        // ]);

//      $product= ProductCategory::create($input)  //insert
//    if($productcategory){
//    return  redirect('ProductCategory');
//     }
// }
