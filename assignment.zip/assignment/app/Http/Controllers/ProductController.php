<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Response;
use App\Models\Product;

class ProductController extends Controller
{
    public function index(){
        $products = Product::where(['product_status' => 'Active'])->get();
        return view('Product',compact('products'));
    }
    public function store(Request $request){
          $input = $request->all();
            //validation
         $this->validate($request,[
              'product_name'=> 'required|min:3',
               'product_price'=> 'required'
           ]);
                  //toastr message  
        $product = Product::create($input);
                    if($product){
            toastr()->warning('Warning Message');

                        return redirect('Product');     
                        
                        }   
                    }
                   //edit
                  public function edit($id){
                    //   $product = Product::findorfail($id);
                    $product= Product::where('product_id',$id)->first();
                      return view('edit_product',compact('product'));
                  }

                  public function update(Request $request){
                      $input = $request->all();
                    //   $search['product_id'] = $input['product_id'];
                    // Product::updateorcreate($search,$input);

                       
                     // method -2
                      unset($input['_token']);
                      unset($input['submit']);
                      Product::where('product_id',$input['product_id'])->update($input);
                      return redirect('Product');
                    // $searchInput['product_id'] = $input['product_id'];
                    // Product::updateorcreate($searchInput,$input);


                    
                  }

                    //destory 
                    public function destroy($id){
                        Product::where('product_id',$id)->delete();

                        return redirect('Product');
                      }
                    }


    //     $product = Product::create($input);
    //  dd($product);

    // return redirect('Product');
// if($product){
//     return redirect('product');

// }

//      $this->validate($request,[
//         'product_name' => 'required|min:3',
//         'product_price' => 'required'
//    ]);   
//  }
// }
