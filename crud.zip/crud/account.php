
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    body{
      background-color:#84817a;
    }
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */

    .row.content {height:1200px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color:#2c2c54;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
  </style>
</head>
<body>
<!--nav bar-->
<nav class="navbar navbar-inverse visible-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="dash.php">Dashboard</a></li>
        <li><a href="home.php">Home</a></li>
        <li><a href="user.php">Users</a></li>
        <li><a href="account.php">My Account</a></li>
        <li><a href="#">Logout</a></li>

      </ul>
    </div>
  </div>
</nav>
<!--sidebar-->
<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav hidden-xs">
      <h2>Logo</h2>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="#section1">Dashboard</a></li>
        <li><a href="dash.php">Home</a></li>
        <li><a href="user.php">Users</a></li>
        <li><a href="account.php">My Account</a></li>
         <li><a href="#">Logout</a></li>
      </ul><br>
    </div>
    <form>

  <div class="form-row">
<div class="form-group col-md-6">
  <h2><center><b>FORM</center></b></h2>
      

    <div class="form-group col-md-6">
      user_name
      <input type="text" class="form-control" id="user_name" placeholder="user_name">
    </div>

    <div class="form-group col-md-6">
     user_email
      <input type="email" class="form-control" id="user_email" placeholder="user_email">
    </div>
    <div class="form-group col-md-6">
      user_password
      <input type="password" class="form-control" id="user_password" placeholder="user_password">
    </div>

 <div class="form-group col-md-6">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</div>
  
</form>
<br>

</head>
</html>