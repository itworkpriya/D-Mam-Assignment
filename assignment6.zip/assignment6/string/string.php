<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> string and array</title>
</head>
<body>
	<!--string -->
	<!--strlen()-->
	<?php
	echo "<h2>strlen()</h2>";
	echo strlen("PRIYA SHARMA");
	echo"<hr>";
	//Count The Number of Words in a String
	 echo"<h2>str_word_count()</h2>";
	 echo str_word_count("KUMUDINI MAM");
	 echo"<hr>";
	 //Reverse a String
	 echo "<h2>Reverse a String</h2>";
	 echo strrev("my name is priya");
        echo"<hr>";
	 //strpos()
	 echo"<h2>Search For a Specific Text Within a String:<br>strpos() </h2>";
	  echo strpos("itworks company", "company");
         echo"<hr>";
         // str_replace()
         //replaces some characters with some other characters in a string.
         echo "<h2>str_replace()</h2>";
         echo str_replace("world", "PRIYA", "Hello world!");
         //
	?> 

</body>
</html>