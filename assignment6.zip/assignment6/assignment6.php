<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

<h4>ARRAY</h4>
<?php
$cars = array("Volvo", "BMW", "Toyota"); 
echo "I like " . $cars[0] . ", " . $cars[1] . " and " . $cars[2] . ".";
echo"<br>";

//count()
echo"<h4>Get The Length of an Array count()</h4>";
$cars = array("Volvo", "BMW", "Toyota");
echo count($cars);

//Indexed Arrays
echo"<h4>Indexed Arrays</h4>";
$cars = array("Volvo", "BMW", "Toyota"); 
echo "I like " . $cars[0] . ", " . $cars[1] . " and " . $cars[2] . ".";

////Associative Array
echo"<h4> Associative Array</h4>";
$age = array("PRIYA"=>"35", "NIKITA"=>"37", "MEETU"=>"43");

foreach($age as $x => $x_value) {
  echo "Key=" . $x . ", Value=" . $x_value;
  echo "<br>";
}

  //Multidimensional Arrays
echo"<h4>Multidimensional Arrays</h4>";
$cars = array (
  array("Volvo",22,18),
  array("BMW",15,13),
  array("Saab",5,2),
  array("Land Rover",17,15)
);
  
echo $cars[0][0].": In stock: ".$cars[0][1].", sold: ".$cars[0][2].".<br>";
echo $cars[1][0].": In stock: ".$cars[1][1].", sold: ".$cars[1][2].".<br>";
echo $cars[2][0].": In stock: ".$cars[2][1].", sold: ".$cars[2][2].".<br>";
echo $cars[3][0].": In stock: ".$cars[3][1].", sold: ".$cars[3][2].".<br>";

//sort Array
echo"<h4>Sort Array in Ascending Order</h4>";

$cars = array("Volvo", "BMW", "Toyota");
sort($cars);

$clength = count($cars);
for($x = 0; $x < $clength; $x++) {
  echo $cars[$x];
  echo "<br>";
}
//sort Array
echo"<h4>Sort Array in Descending  Order</h4>";
$cars = array("Volvo", "BMW", "Toyota");
rsort($cars);

$clength = count($cars);
for($x = 0; $x < $clength; $x++) {
  echo $cars[$x];
  echo "<br>";
}

?>
<hr>
<?php
//strlen() - Return the Length of a String
echo"<h3>string</h3>";
echo"<h4> strlen()-Return the Length of a String</h4>";
echo strlen("Priya Sharma");
//str_word_count() - Count Words in a String
echo"<h4>echo str_word_count</h4>";
echo str_word_count("Hello priya!"); // outputs 2

//strrev()
echo"<h4>strrev()</h4>";
echo strrev("Hello world!");
//strpos()
echo"<h4>strpos()</h4>";

echo strpos("Hello world!", "world");
//str_replace() 
echo"<h4>str_replace()</h4>";
echo str_replace("world", "priya", "Hello world!");


?>
</body>
</html>