<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Swap no</title>
</head>
<body>
<?php 
echo "using variable"; 
$a = 45;  
$b = 78;  
// Swapping Logic  
$third = $a;  
$a = $b;  
$b = $third;  
echo "After swapping:<br><br>";  
echo "a =".$a."  b=".$b;  
echo"<br>";
 #Without using variable
echo"without using variable";
 
$a=234;  
$b=345;  
//using arithmetic operation  
$a=$a+$b;  
$b=$a-$b;  
$a=$a-$b;  
echo "Value of a: $a</br>";  
echo "Value of b: $b</br>";  
?>  
 
</body>
</html>