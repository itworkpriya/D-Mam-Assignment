<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>palindrome or not</title>
</head>
<body>
	<!--write a program to check string is palindrome or not?-->
	<?php
function Palindrome($MyString) {
  $l = 0;
  $r = strlen($MyString) - 1;
  $x = 0;

  while($r > $l){
    if ($MyString[$l] != $MyString[$r]){
      $x = 1;
      break;
    }
    $l++;
    $r--;
  }

  if ($x == 0){
    echo $MyString." is a Palindrome string.\n";
  } else {
    echo $MyString." is not a Palindrome string.\n";
  }
}

Palindrome("121121");
echo"<br>";
Palindrome("priya");
echo"<br>";
Palindrome("madam");
echo"<br>";
?>


</body>
</html>