<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>print an array</title>
</head>
<body>
<?php
// PHP program to print all
// the values of an array
	
// given array
$array = array("PRIYA1", "PRIYA2",
		"PRIYA3", "1", "2","3");

// Loop through array
foreach($array as $item){
	echo $item . "\n";
}
echo "<br>";
echo "<br>";

#using foreach loop 
echo"each element of an array";
echo "<br>";
$cars = array("BMW", "Ford", "Hyundai", "Jaguar");
 
foreach ($cars as $value) {
  echo "$value <br>";
}

?>

</body>
</html>