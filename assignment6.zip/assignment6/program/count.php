<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>count using loop</title>
</head>
<body>
<?php
$count = 5;
while($count <= 15)
{
  echo $count;
  echo "<br>" ;

  $count++;
}

echo"<hr>";

# if -else statement program
echo"if-else statement";
echo"<br>";
$marks = 40;

if ($marks>=60)
{
	$grade = "First Division";
}
else if($marks>=45)
{
	$grade = "Second Division";
}
else if($marks>=33)
{
	$grade = "Third Division";
}
else
{
	$grade = "Fail";
}

echo "Student grade: $grade";

echo"<hr>";
//check vote
//Condition
//Minimum age required for vote is 18.
// use PHP Functions.
// use Decision Making Statements.
function check_vote() //function has been declared
{
    $name = "Priya";
    $age = 25;
    if ($age >= 18) {
        echo $name . ", you Are Eligible For Vote";
      
    } else {
        echo $name . ", you are not eligible for vote. ";
       
    }
}
check_vote(); //function has been called


?>
</body>
</html>