<!DOCTYPE html>
<html>
<body>

<?php
$numbers = array(40, 61, 2, 22, 13);
sort($numbers);

$arrlength = count($numbers);
for($x = 0; $x < $arrlength; $x++) {
	echo $numbers[$x];
	echo "<br>";
}
echo"<hr>";

echo "decending order";
$numbers = array(40, 61, 2, 22, 13);
rsort($numbers);
  
$arrlength = count($numbers);
for($x = 0; $x < $arrlength; $x++) {
    echo $numbers[$x];
    echo "<br>";
}
echo"<hr>";
# sum of element 

//Initialize array   
$arr = array(1, 2, 3, 4, 5);   
$sum = 0;  
   
//Loop through the array to calculate sum of elements  
for ($i = 0; $i < count($arr); $i++) {   
   $sum = $sum + $arr[$i];  
}    
print("Sum of all the elements of an array: " . $sum);
echo"<br>"; 

#remove  the duplicated value
echo"from an Associative array";
// Input array
$arr = array(
      "a" => "MH", 
      "b" => "JK", 
      "c" => "JK", 
      "d" => "OR"
);
  
// Array after removing duplicates
print_r(array_unique($arr));
echo"<hr>";
  
 

?>



</body>
</html>
