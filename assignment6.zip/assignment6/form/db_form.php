<?php
echo $First_Name=$_POST['fname'];
echo "<br>";
echo $Second_Name=$_POST['sname'];
echo "<br>";
echo $Email_id=$_POST['email'];
echo "<br>";
echo $Password=$_POST['password'];
echo "<br>";
echo $Re_Password=$_POST['repassword'];
echo "<br>";
echo $Pin_no=$_POST['pin'];
echo "<br>";
echo $Phone_no=$_POST['phone_no'];
echo "<br>";
?>





