<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>palindrome or not</title>
	<style>

	body {

 background-color: #cccccc;
}
</style>
</head>
<body>
	<!--write a program to check string is palindrome or not?-->
	<?php
		echo"<h2>string is palindrome or not </h2>";
		$s="madam";
		$rev=strrev($s);
		if($s==$rev){
			echo "$s is Pailndrome";
		}
		else{
			echo "$s is not Pailndrome";
		}

echo"<hr>";
?>

<!--write a program to check string is palindrome or not?-->
	<?php
function Palindrome($MyString) {
  $l = 0;
  $r = strlen($MyString) - 1;
  $x = 0;

  while($r > $l){
    if ($MyString[$l] != $MyString[$r]){
      $x = 1;
      break;
    }
    $l++;
    $r--;
  }

  if ($x == 0){
    echo $MyString." is a Palindrome string.\n";
  } else {
    echo $MyString." is not a Palindrome string.\n";
  }
}

Palindrome("121121");
echo"<br>";
Palindrome("priya");
echo"<br>";
Palindrome("madam");
echo"<br>";
echo"<hr>";
?>

<!--Write a program to print fibonacci series without using recursion-->
<?php
	echo"<h2>print fibonacci series without using recursion </h2>";
	// 0 1 1 2 3 5 8 13 
	//add two number
if(isset($_POST['submit'])){

	$limit=$_POST['number'];

	$n1 = 0;
	$n2 = 1;
	$x = 0;
for($i=0;$i<=$limit;$i++){
	echo "$n1";
	$n1 = $n1 +$n2; //assignment operater
	$n2= $x;
	$x=$n1;
	echo "<br>";
 }
}


?>
<form method="post">
	<input type="text"name="number"required/>
	<input type="submit" name="submit"/>
</form>
<hr>
<?php
	$num = 12345;
$forThisNumber = $num;
$rev = 0;
while($num > 0)
{
  $a = $num % 10; // 1st time = 5
  $rev = ($rev * 10) + $a; // second time54
  $num = (int)($num / 10); // 3rd time remained = 123
}
echo "original number is =  <b> $forThisNumber </b> <br/>  Reverse of number is = <b> $rev </b>";
echo "<hr>";

//Write a program to reverse given string
$str = "This is string reverse logic without using any inbuild functions";
$rev = "";
$i = 0;

while(@$str[$i++] != NULL);  //  5*10+4= 54 
                              // 54*10+3 = 540+3=543
                               //543*10+2=5430+2=5432
                               //5432*10+1=54320+1=54321
$i--;

while($i >= 0)
{
    $rev = $rev.@$str[$i--];
}
echo "Original String : ".$str;
echo "<br><br>reverse String : ".$rev;

echo "<hr>";


//Write a program to swap two numbers with and without using third variable

$a=10;
$b=20;
echo"a before swapping : ", $a,"<br>";
echo"b before swapping : ", $b,"<br>";
//logic
 $a=$a+$b;//30    //assignment operator
 $b=$a-$b;//30-20=10
$a=$a-$b;//30-10=20
echo"a after swapping : ", $a,"<br>";
echo"b after swapping : ", $b,"<br>";
echo"<hr>";

?>

<?php
//Write a program to swap two numbers with  using third variable
$a = 45;  
$b = 78;  
// Swapping Logic  
$third = $a;  //assignment
$a = $b;  
$b = $third;  
echo "After swapping:<br><br>";  
echo "a =".$a."  b=".$b;
echo"<hr>"; 
?> 
 
<?php
//Write a program to find if the given year is leap year or not
function isLeapYear($year){
	if(!is_numeric($year)){
		echo "string is not  allowed. Input should be a number.";
		return;

	}
	//check leap year
	if(($year%4 == 0 && $year%100!=0) || $year%400==0){
		echo $year, "is a Leap Year"; //leap year is a one which has 366 days in year.
		// leap year always a multiple of four.
		//year%4==0 evenly divisible by 4
		//year%100!=0 should not  be evenly divisible by 100
		//or year%400==0 evenly divisible by 400.
}else{
		echo $year,"is not a Leap Year";
	}
}
$year="2020";
isLeapYear($year);

echo"<hr>";

?>
<?php
//Write a program to print an array
// PHP program to print all
// the values of an array
	
// given array
$array = array("PRIYA1", "PRIYA2",
		"PRIYA3", "1", "2","3");

// Loop through array
foreach($array as $item){
	echo $item . "\n";
}
echo "<br>";
echo "<br>";

#using foreach loop 
echo"each element of an array";
echo "<br>";
$cars = array("BMW", "Ford", "Hyundai", "Jaguar");
 
foreach ($cars as $value) {
  echo "$value <br>";
}
echo"<hr>";
?>

<?php
//ascending 
//decending
$numbers = array(40, 61, 2, 22, 13);
sort($numbers);

$arrlength = count($numbers);
for($x = 0; $x < $arrlength; $x++) {
	echo $numbers[$x];
	echo "<br>";
}
echo"<hr>";

echo "decending order";
$numbers = array(40, 61, 2, 22, 13);
rsort($numbers);
  
$arrlength = count($numbers);
for($x = 0; $x < $arrlength; $x++) {
    echo $numbers[$x];
    echo "<br>";
}
echo"<hr>";
# sum of element 

//Initialize array   
$arr = array(1, 2, 3, 4, 5);   
$sum = 0;  
   
//Loop through the array to calculate sum of elements  
for ($i = 0; $i < count($arr); $i++) {   
   $sum = $sum + $arr[$i];  
}    
print("Sum of all the elements of an array: " . $sum);
echo"<br>"; 

#remove  the duplicated value
echo"from an Associative array";
// Input array
$arr = array(
      "a" => "MH", 
      "b" => "JK", 
      "c" => "JK", 
      "d" => "OR"
);
  
// Array after removing duplicates
print_r(array_unique($arr));
echo"<hr>";
 ?>
<!--factorial number-->
 <form method="post">  
    Enter the Number:<br>  
    <input type="number" name="number" id="number">  
    <input type="submit" name="submit" value="Submit" />  
</form>  
<?php   
    if($_POST){  
        $fact = 1;  
        //getting value from input text box 'number'  
        $number = $_POST['number'];  
        echo "Factorial of $number:<br><br>";  
        //start loop  
        for ($i = 1; $i <= $number; $i++){         
            $fact = $fact * $i;  
            }  
            echo $fact . "<br>";  
    } 
    echo"<hr>"; 
?>

<?php
 //Write a program to count 5 to 15 using loop

 $count = 5;
while($count <= 15)
{
  echo $count;
  echo "<br>" ;

  $count++;
}

echo"<hr>";

# if -else statement program
echo"if-else statement";
echo"<br>";
$marks = 40;

if ($marks>=60)
{
	$grade = "First Division";
}
else if($marks>=45)
{
	$grade = "Second Division";
}
else if($marks>=33)
{
	$grade = "Third Division";
}
else
{
	$grade = "Fail";
}

echo "Student grade: $grade";

echo"<hr>";

//check vote
//Condition
//Minimum age required for vote is 18.
// use PHP Functions.
// use Decision Making Statements.
function check_vote() //function has been declared
{
    $name = "Priya";
    $age = 25;
    if ($age >= 18) {
        echo $name . ", you Are Eligible For Vote";
      
    } else {
        echo $name . ", you are not eligible for vote. ";
       
    }
}
check_vote(); //function has been called

echo"<hr>";
?>
	



</body>
</html>