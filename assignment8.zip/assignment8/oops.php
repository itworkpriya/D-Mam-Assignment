<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ASSIGNMENT8</title>
</head>
<body>
	<?php
//Example for Abstract class
	echo"<h1>Example for Abstract class</h1>";
abstract class Cars {
    public abstract function getCompanyName();
    public abstract function getPrice();
}
class Baleno  extends Cars {
    public function getCompanyName() {
        return "Maruthi Suzuki" . '<br/>';
    }
    public  function getPrice() {
      return 720000 . '<br/>';
    }
}
class Santro extends Cars {
    public function getCompanyName() {
        return "Hyundai" . '<br/>';
    }
    public function getPrice() {
        return 300000 . '<br/>';
    }
}
$car = new Baleno();
$car1 = new Santro();
echo $car->getCompanyName();
echo $car->getPrice();
echo $car1->getCompanyName();
echo $car1->getPrice();
echo"<hr>";


//Example for interface
echo"<h1>Example for interface</h1>";
interface MyInterfaceName{

	public function method1();
	public function method2();

}

class MyClassName implements MyInterfaceName{

	public function method1(){
		echo "Method1 Called" . "\n";
	}

	public function method2(){
		echo "Method2 Called". "\n";
	}
}

$obj = new MyClassName;
$obj->method1();
echo"<br>";
$obj->method2();
echo"<hr>";


?>
</body>
</html>