<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dashboard</title>
  <meta charset="utf-8">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body{
      background-color:#84817a;
    }
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */

    .row.content {height:1200px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color:#2c2c54;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
  </style>
</head>
<body>
<!--nav bar-->
<nav class="navbar navbar-inverse visible-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="dash.php">Dashboard</a></li>
        <li><a href="home.php">Home</a></li>
        <li><a href="user.php">Users</a></li>
        <li><a href="account.php">My Account</a></li>
        <li><a href="#">Logout</a></li>

      </ul>
    </div>
  </div>
</nav>
<!--sidebar-->
<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav hidden-xs">
      <h2>Logo</h2>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="dash.php">Dashboard</a></li>
        <li><a href="home.php">Home</a></li>
        <li><a href="user.php">Users</a></li>
        <li><a href="account.php">My Account</a></li>
         <li><a href="#">Logout</a></li>
      </ul><br>
    </div>
    <br>
    <div class="col-sm-9">
      <div class="well">
        <p>Hey, <?php echo $_SESSION['username']; ?>!</p>
        <h4>Dashboard</h4>
        <p><a href="logout.php">Logout</a></p>
        
      </div>





   
    


    </body>
    </html>
