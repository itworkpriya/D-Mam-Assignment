<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>


<?php

// Function to find the difference
// between two dates.
function dateDiffInDays($date1, $date2)
{
	// Calculating the difference in timestamps
	$diff = strtotime($date2) - strtotime($date1);

	// 1 day = 24 hours
	// 24 * 60 * 60 = 86400 seconds
	return abs(round($diff / 86400));
}

// Start date
$date1 = "17-09-2018";

// End date
$date2 = "31-09-2018";

// Function call to find date difference
$dateDiff = dateDiffInDays($date1, $date2);

// Display the result
printf("Difference between two dates: "
	. $dateDiff . " Days ");
echo"<hr>";

# Write a program in PHP to find the occurrence of a word in a string
// PHP program to count the number
// of occurrence of a word in
// the given string

function countOccurrences($str, $word)
{
	// split the string by spaces
	$a = explode(" ", $str);

	// search for pattern in string
	$count = 0;
	for ($i = 0; $i < sizeof($a); $i++)
	{
		
	// if match found increase count
	if ($word == $a[$i])
		$count++;
	}

	return $count;
}

// Driver code
$str = "itworks A computer science portal portal for itworks";
$word = "portal";
echo (countOccurrences($str, $word));
echo "<hr>";



#Write a program for this pattern ?
echo "<h3>pattern</h3>";
for($i=0;$i<=5;$i++)
{  
for($j=5-$i;$j>=1;$j--)
{  
echo "* ";  
}  
echo "<br>";  
} 
echo "<hr>";   	

 # Write a program to print below format
for ($i=1; $i<=8; $i++)	
{	 
for($j=1;$j<=$i;$j++)	  
{	  	
echo $j." ";	 
}	  	
echo "<br/>";   	
}  
echo "<hr>";

# Write a Program for finding the biggest number in an array without using any array functions.
$numbers = array(0,10,80,67,60,89,91,56,45,30,95,83);
$length = count($numbers);
$max = $numbers[0];
for($i=1;$i<$length;$i++)
{
if($numbers[$i]>$max)
{
$max = $numbers[$i];
}
}
Echo "the biggest number in the array is ".$max;
echo "<hr>";

# Write a Program for finding the smallest number in an array
$numbers = array(2,17,40,22,5,6,14,7,19,54);
$length = count($numbers);
$min = $numbers[0];
for($i=1;$i<$length;$i++)
{
if($numbers[$i]<$min)
{
$min=$numbers[$i];
}
}
echo "The smallest number is ".$min;
echo"<hr>";


 # Write a program to concatenate two strings character by character. e.g : INFOTECH + ITWORKS = INFOTECHITWORKS



// First String
$a = 'INFOTECH';

// Second String
$b = 'ITWORKS!';

// Concatenation Of String
$c = $a.$b;

// print Concatenate String
echo " $c \n";
echo"<hr>";

# PHP program to find second largest
# element in an array
 
// Function to print the
// second largest elements
function print2largest($arr, $arr_size)
{
 
    // There should be atleast
    // two elements
    if ($arr_size < 2)
    {
        echo(" Invalid Input ");
        return;
    }
 
    $first = $second = PHP_INT_MIN;
    for ($i = 0; $i < $arr_size ; $i++)
    {
         
        // If current element is
        // smaller than first
        // then update both
        // first and second
        if ($arr[$i] > $first)
        {
            $second = $first;
            $first = $arr[$i];
        }
 
        // If arr[i] is in
        // between first and
        // second then update
        // second
        else if ($arr[$i] > $second &&
                 $arr[$i] != $first)
            $second = $arr[$i];
    }
    if ($second == PHP_INT_MIN)
        echo("There is no second largest element\n");
    else
        echo("The second largest element is " . $second . "\n");
}
 
// Driver Code
$arr = array(12, 35, 1, 10, 34, 1);
$n = sizeof($arr);
print2largest($arr, $n);
echo"<hr>";
# What will be the output of the code below

$x = 5;
echo $x;
//print 5
echo "<br />";
echo $x+++$x++;//5+6=11
echo "<br />";
echo $x;//7
echo "<br />";
echo $x---$x--;//7-6=1

echo "<br />";
echo $x;       //5
echo "<br />";

echo "<hr>";
#
$x = true and false; //Operator Precedence rule
var_dump($x);  //Because 'and/or' have lower priority than '=' but '||/&&' have higher


echo "<hr>";
# Write a program to print string 
$str=" MYMAMNAMEISKUMUDINIPATIL";
$count=strlen($str);
for($i=0;$i<$count;$i++){
    for($j=0;$j<=$i;$j++){
        echo"$str[$j]";
    }
    echo"<br>";
}

echo "<hr>";

?>

</body>
</html>
